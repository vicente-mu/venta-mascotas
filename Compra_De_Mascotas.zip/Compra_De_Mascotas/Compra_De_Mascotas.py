import os
from datetime import datetime
import pyfiglet

os.system("cls")
data=datetime.now()

fecha=f'{data.day:02d}-{data.month:02d}-{data.year}'

archivo= 'Datos_Mascotas.txt'
archivo2= 'Ventas_Folio.txt'

mascotas = []
ventas= []
    
total=0

def es_bisiesto(anio):

    return anio % 4 == 0 and (anio % 100 != 0 or anio % 400 == 0)

def validar_fecha(fecha):

    if len(fecha) != 10:
        return -1
    
    try:
        dia, mes, anio = map(int, fecha.split('-'))
    except ValueError:
        return -1
    
    if not (1 <= dia <= 31) or not (1 <= mes <= 12) or anio <= 2000:
        return -1
    
    if mes == 2:
        if es_bisiesto(anio):
            if dia > 29:
                return -1
        else:
            if dia > 28:
                return -1
    
    dias_en_mes = [31, 29 if es_bisiesto(anio) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if dia > dias_en_mes[mes - 1]:
        return -1
    
    return 1

def confirmar(opcion):
    while True:
        opcion = opcion.strip().lower()
        if opcion == "s":
            return True
        elif opcion == "n":
            return False
        else:
            print("Opción no válida. Por favor, ingrese 's' para sí o 'n' para no.")
            opcion = input("Ingrese su opción (s/n): ")

def inicio_sistema():
    print(pyfiglet.figlet_format("Central de compra de Mascotas!", justify="center"))
    print("\n\n")
    print("                                     Autores: Manuel Acuña")
    print("                                              Vicente Muñoz")
    print("\n\n")
    os.system("pause")

def convertir_a_fecha(fecha_str):

    return datetime.strptime(fecha_str, '%d-%m-%Y')


def leer_datos_archivo(archivo):

    lista_datos = []

    with open(archivo, 'r') as file:
        for linea in file:
            linea = linea.strip()
            datos = linea.split(',')
            lista_datos.append([datos[0],datos[1],datos[2],datos[3],datos[4],int(datos[5]),int(datos[6])])

    return lista_datos

def leer_datos_archivo2(archivo2):

    lista_ventas = []

    with open(archivo2, 'r') as file:
        for linea in file:
            linea = linea.strip()
            datos = linea.split(',')
            lista_ventas.append([int(datos[0]),datos[1],datos[2],int(datos[3]),int(datos[4])])
    
    return lista_ventas


def buscar_id(id):

    lista_datos = []

    with open(archivo, 'r') as file:

        for linea in file:
            linea = linea.strip()
            datos = linea.split(',')

            if datos[0] == id:

                return datos
            
    return -1

def obtener_folio():

    lista_ventas = []

    with open(archivo2, 'r') as file:

        for linea in file:
            linea=linea.strip()
            datos = linea.split(',')
            folio=int(datos[0])
            folio+=1
    return folio
        


def eliminar(id):

    lista_datos_actualizada = []

    existe=buscar_id(id)

    if existe != -1:

        with open(archivo, 'r') as file:

            for linea in file:
                linea = linea.strip()
                datos = linea.split(',')
                if datos[0] != id:
                    lista_datos_actualizada.append(linea)
                
        with open(archivo, 'w') as file:
            for linea in lista_datos_actualizada:
                file.write(linea + '\n')
        return 1
    else:
        return -1

def imprimir_ventas(lista_ventas):
    for x in lista_ventas:
        print (x[0]," ",x[1]," ",x[2]," ",x[3]," ",x[4])
    
def imprimir_datos(lista_datos):
    for x in lista_datos:
        print (x[0]," ",x[1]," ",x[2]," ",x[3]," ",x[4]," ",x[5]," ",x[6])

def cargar_ventas(lista_ventas):
    with open(archivo2, "r") as file:
        for linea in file:
            linea=linea.strip()
            datos=linea.split(',')
            if datos[0]!="":
                ventas.append([int(datos[0]),datos[1],datos[2],int(datos[3]),int(datos[4])])
    return 1

def cargar_mascotas(lista_datos):
    with open(archivo, "r") as file:
        for linea in file:
            linea=linea.strip()
            datos=linea.split(',')
            if datos[0]!="":
                mascotas.append([datos[0],datos[1],datos[2],datos[3],datos[4],int(datos[5]),int(datos[6])])

    return 1

def actualizar_mascotas(lista_datos,mascotas):
    for x in mascotas:
        if x==0:
            None
        else:
            ultima_linea=len(mascotas)
            with open(archivo, "w") as file:
                c=1
                for x in mascotas:
                    if c!=ultima_linea:
                        file.write(f"{x[0]},{x[1]},{x[2]},{x[3]},{x[4]},{x[5]},{x[6]}\n")
                    else:
                        file.write(f"{x[0]},{x[1]},{x[2]},{x[3]},{x[4]},{x[5]},{x[6]}")
                    c+=1
    return 1

def actualizar_ventas(lista_ventas,ventas):
    for x in ventas:
        if x==0:
            None
        else:
            ultima_linea=len(ventas)
            with open(archivo2, "w") as file:
                c=1
                for x in ventas:
                    if c!=ultima_linea:
                        file.write(f"{x[0]},{x[1]},{x[2]},{x[3]},{x[4]}\n")
                    else:
                        file.write(f"{x[0]},{x[1]},{x[2]},{x[3]},{x[4]}")
                    c+=1
    return 1


def agregar_datos(id, nombre, raza, fecha_nacimiento, genero, stock, precio):

    with open(archivo, 'a') as file:

        file.write(f"\n{id},{nombre},{raza},{fecha_nacimiento},{genero},{stock},{precio}")

def agregar_ventas(folio, fecha, id, cantidad, total):
    
    with open(archivo2, 'a') as file:

        file.write(f'\n{folio},{fecha},{id},{cantidad},{total}')

def modificar(nuevo_nombre, nueva_raza, nueva_fecha_nacimiento, nuevo_genero, nuevo_stock, nuevo_precio):
    
    lista_datos_actualizada = []

    id_encontrado = False

    with open(archivo, 'r') as file:
        for linea in file:
            linea = linea.strip()
            datos = linea.split(',')
            if datos[0] == id:
                datos[1] = nuevo_nombre
                datos[2] = nueva_raza
                datos[3] = nueva_fecha_nacimiento
                datos[4] = nuevo_genero
                datos[5] = str(nuevo_stock)
                datos[6] = str(nuevo_precio)
                id_encontrado = True

            lista_datos_actualizada.append(','.join(datos))

    if not id_encontrado:
        return -1
    
    with open(archivo, 'w') as file:

        for linea in lista_datos_actualizada:
            file.write(linea + '\n')

    return 1

opcion=0
inicio_sistema()
while True:
    os.system("cls")
    opcion=0
    print(f"""
            VENTA MASCOTAS
    -----------------------------
                                        fecha: {fecha}
                                        versión v003
          1. Comprar mascota
          2. Reportes
          3. Menú Mantenedores
          4. Administración
          5. Salir

            """)
    try: opcion=int(input("Ingrese una opción: "))
    except: pass
    if opcion >=1 and opcion <=5:
        os.system("cls")
        match opcion:
            case 1:
                while True:
                    otra_compra=confi=""
                    os.system("cls")
                    print("""
                COMPRA DE MASCOTAS
        ---------------------------------      
                          
                          """)
                    id=input("Ingrese el ID de la mascota a comprar: ")
                    buscar=buscar_id(id)
                    if buscar!=-1:
                        print("Mascota encontrada")
                        print(buscar,'\n')
                        try: cantidad=int(input("Ingrese la cantidad de mascotas a comprar: "))
                        except: 
                            print("Error, formato de cantidad no valida...")
                            break
                        if cantidad <= (buscar[5]):
                            print("Stock disponible...")
                            total+=(cantidad*(int(buscar[6])))
                            print(f"Total a pagar: ${total}")
                            confi=input("Desea confirmar la compra? (s/n): ")
                            if confirmar(confi):
                                print("Venta realizada con éxito\n")
                                folio=obtener_folio()
                                agregar_ventas=(folio,fecha,id,cantidad,total)
                            else:
                                print("Venta cancelada...")
                                os.system("pause")
                                break
                        else:
                            print("No hay stock disponible...")
                        otra_compra=input("Desea realizar otra compra? (s/n): ")
                        if confirmar(otra_compra):
                            pass
                        else:
                            break
                    else:
                        print(f"Error, el id: '{id}' no esta asignado a ninguna mascota...")
                os.system("pause")
            case 2:
                while True:
                    op=0
                    os.system("cls")
                    print("""
                    REPORTE DE VENTAS
            --------------------------------
                1. General de ventas (con total)
                2. Ventas por fecha especifica (con total)
                3. Ventas por rango de fecha (con total)
                4. Salir al menú principal
                        
                        """)
                    try: op=int(input("Ingrese una opcion 1-4: "))
                    except: pass
                    if op >=1 and op <=4:
                        os.system("cls")
                        match op:
                            case 1:
                                total=0
                                print("Reporte general de ventas\n")
                                ventas=leer_datos_archivo2(archivo2)
                                imprimir_ventas(ventas)
                                for x in ventas:
                                    total+=x[4]
                                print(f"Total de ventas: ${total}")
                            case 2:
                                print("Reporte de ventas por fecha especifica\n")
                                fecha_especifica=input("Ingrese la fecha: ")
                                resultado = validar_fecha(fecha_especifica)
                                if resultado == 1:
                                    ventas=leer_datos_archivo2(archivo2)
                                    for x in ventas:
                                        if x[1]==fecha_especifica:
                                            print(f"{x[0]}  {x[1]}  {x[2]}  {x[3]}  {x[4]}")
                                            total+=x[4]
                                    if total >0:
                                        print(f"Total de ventas en la fecha '{fecha_especifica}: ${total}")
                                    else: 
                                        print("No hay ventas en la fecha especificada...")
                                else:
                                    print("Fecha invalida...")
                            case 3:
                                print("Ventas por rango de fechas\n")
                                fecha_1=input("Ingrese la fecha inicial: ")
                                fecha_2=input("Ingrese la fecha final: ")
                                resultado_1 = validar_fecha(fecha_1)
                                resultado_2 = validar_fecha(fecha_2)
                                if resultado_1 == 1 and resultado_2 == 1:
                                    ventas=leer_datos_archivo2(archivo2)
                                    fecha_inicio= convertir_a_fecha(fecha_1)
                                    fecha_fin= convertir_a_fecha(fecha_2)
                                    for x in ventas:
                                        fecha_venta= convertir_a_fecha(x[1])
                                        if fecha_inicio <= fecha_venta <= fecha_fin:
                                            print(f"{x[0]}  {x[1]}  {x[2]}  {x[3]}  {x[4]}")
                                            total+=x[4]
                                    if total>0:
                                        print(f"Total de ventas en el rango de fechas '{fecha_1}' y '{fecha_2}' : ${total}")
                                    else:
                                        print("No hay ventas en el rango de fechas especificado...")
                                else:
                                     print("Fechas invalidas...")
                            case 4:
                                print("Saliendo al menú principal...")
                                os.system("pause")
                                break
                        os.system("Pause")
                    else:
                        print("Opción no válida...")
                        os.system("pause")
            case 3:
                while True:
                    op=0
                    os.system("cls")
                    print("""
                        MENÚ MANTENEDORES
                --------------------------------
                        1. Agregar mascota
                        2. Buscar mascota
                        3. Eliminar mascota
                        4. Modificar mascota
                        5. Listar mascotas
                        6. Salir al menú principal
                        
                    """)
                    try: op=int(input("Ingrese una opción entre 1-6: "))
                    except: pass
                    if op>=1 and op<=6:
                        os.system("cls")
                        match op:
                            case 1:
                                mascotas=leer_datos_archivo(archivo)
                                print("Agregar mascota\n")
                                id=input("Ingrese el id de la mascota: ")
                                buscar=buscar_id(id)
                                if buscar==-1:
                                    try:
                                        nombre=input("Ingrese el nombre de la mascota: ")
                                        raza=input("Ingrese la raza de la mascota: ")
                                        fecha_nacimiento=input("Ingrese la fecha de nacimiento de la mascota: ")
                                        genero=input("Ingrese el genero de la mascota: ")
                                        stock=int(input("Ingrese el stock de la mascota: "))
                                        precio=int(input("Ingrese el precio de la mascota: "))
                                    except:
                                        print("\nError en el ingreso de datos...")
                                        os.system("pause")
                                        break
                                    agregar_datos(id,nombre,raza,fecha_nacimiento,genero,stock,precio)
                                    print("Mascota agregada con éxito...")
                                else:
                                    print("El id ya existe...")
                                    break
                        
                            case 2:
                                print("Buscar mascota\n")
                                id=input("Ingrese el id de la mascota a buscar: ")
                                buscar=buscar_id(id)
                                if buscar!=-1:
                                    print("Mascota encontrada")
                                    print(buscar,'\n')
                                else:
                                    print(f"Error, el id: '{id}' no esta asignado a ninguna mascota...")
                            case 3:
                                print("Eliminar mascota\n")
                                id=input("Ingrese el id de la mascota a eliminar: ")
                                buscar=eliminar(id)
                                if buscar!=-1:
                                    print("Mascota eliminada")
                                else:
                                    print(f"Error, el id: '{id}' no esta asignado a ninguna mascota...")
                            case 4:
                                print("\nModificar mascota\n")
                                id=input("Ingrese el id de la mascota a modificar: ")
                                buscar=buscar_id(id)
                                if buscar!=-1:
                                    try:
                                        print("Mascota encontrada")
                                        print(buscar,'\n')
                                        nuevo_nombre=input("Ingrese el nuevo nombre: ")
                                        nueva_raza=input("Ingrese la nueva raza: ")
                                        nueva_fecha_nacimiento=input("Ingrese la nueva fecha de nacimiento: ")
                                        nuevo_genero=input("Ingrese el nuevo genero: ")
                                        nuevo_stock=int(input("Ingrese el nuevo stock: "))
                                        nuevo_precio=int(input("Ingrese el nuevo precio: "))
                                    except:
                                        print("Error en el ingreso de datos...")
                                        os.system("pause")
                                        break
                                    mod=modificar(id,nuevo_nombre,nueva_raza,nueva_fecha_nacimiento,nuevo_stock,nuevo_precio)
                                    print("\n Datos modificados con exito!")
                                else:
                                    print(f"Error, el id: '{id}' no esta asignado a ninguna mascota...")
                            case 5:
                                print("\n Listar mascotas \n")
                                mascotas=leer_datos_archivo(archivo)
                                imprimir_datos(mascotas)
                            case 6:
                                print("Saliendo al menú principal...")
                                os.system("pause")
                                break
                        os.system("pause")
                    else:
                        print("Opción fuera de rango...")
                        os.system("pause")
            case 4:
                while True:
                    op=0
                    os.system("cls")
                    print("""
                    Administracion
            -----------------------------
                    1. Cargar datos
                    2. Respaldar Datos
                    3. Salir al menú principal

                        """)
                    try: op=int(input("Ingrese una opción: "))
                    except: pass
                    if op>=1 and op<=3:
                        os.system("cls")
                        match op:
                            case 1:
                                print("Cargar datos\n")
                                cargar_mascotas(archivo)
                                cargar_ventas(archivo2)
                                print("Datos cargados con éxito...")
                            case 2:
                                print("Respaldar datos\n")
                                actualizar_mascotas(archivo,mascotas)
                                actualizar_ventas(archivo2,ventas)
                                print("Datos respaldados...")
                            case 3:
                                print("Saliendo al menú principal...")
                                os.system("pause")
                                break
                        os.system("pause")
                    else:
                        print("Opción fuera de rango...")
                        os.system("pause")

            case 5:
                print("Saliendo del programa...")
                break
    else:
        print("Opción no válida...")
        os.system("pause")